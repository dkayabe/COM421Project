# COM421Project
===============
website with resume, written with html and css


# Walkthrough of website
========================
In the website, there are 2 pages. The first is a description of the resume, where it lists 
the information such as current and past coursework, experience, and skills. In addition, near 
the top of the page, there are 2 clickable links. The left one brings you to the "About Me" page, 
where it gives more information about projects, and more information detailing me as a person. The 
right link allows the user to download the resume as a .pdf file.

In the About Me page, projects are talked about briefly at the top, where I give a short description 
about the past projects I've done, and how they are all on GitHub. Below the description, I have a 
clickable GitHub icon where it brings the user to my GitHub, where they can view projects. After that, 
there is a short description that describes my musical interests, giving some of my background 
on music, and below that, I have a youtube icon which is linked to my YouTube channel (shameless plug, 
but feel free to subscribe if you want!). And lastly, it talks about my least important hobby, which 
is gaming, something I do in my free time. I briefly talk about which games I play, and some future 
plans for gaming. Also, I have a profile picture of me at the top of the page.

Some things that I wish I could have done but didn't have time to execute were the implementation of 2 
columns to make things look neater and tighter rather than having everything just go from top to bottom.
In addition, I didn't have time to fix some margins to make them look cleaner. Overall, I think I had the 
basic things down but didn't have the time for some of the finer details.